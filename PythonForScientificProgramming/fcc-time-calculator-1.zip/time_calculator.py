def add_time(start, duration, weekday=''):
    # "11:06 PM", "2:02", "Monday"
    new_time = ''
    ampm = start.split(' ')[1]
    hr = int(start.split(':')[0])
    mins = int(start.split(':')[1][:2])
    # print(ampm, hr, mins)

    hours = int(duration.split(':')[0])
    minutes = int(duration.split(':')[1])
    # print(hours, minutes)

    weekday_mapping =  {
        'monday': 0,
        'tuesday': 1,
        'wednesday': 2,
        'thursday': 3,
        'friday': 4,
        'saturday': 5,
        'sunday': 6,
    }

    weekday_mapping_=  {
        0:'Monday',
        1:'Tuesday',
        2:'Wednesday',
        3:'Thursday',
        4:'Friday',
        5:'Saturday',
        6:'Sunday',
    }
    mins_to_next_day = 1440 - ((hr * 60) + mins + (0 if ampm=='AM' else 720))
    duration_mins = hours*60 + minutes
    days = 0 if duration_mins < mins_to_next_day else 1 + ((duration_mins-mins_to_next_day) // 1440)
    # days = days + ((duration_mins-mins_to_next_day) // 1440)

    hours = hours % 24
    hrhours = hr + hours
    mins = mins + minutes

    hrhours = hrhours + mins // 60
    AM = 'AM'
    PM = 'PM'
    toggle_ampm = {AM: PM, PM: AM}
    ampm = toggle_ampm[ampm] if (hrhours//12)%2==1 else ampm

    hrhours = 12 if (hrhours % 12)==0 else hrhours % 12
    minsminutes = mins % 60
    # print(hrhours, minsminutes)

    if weekday != '':
        weekday_number = (weekday_mapping[weekday.lower()] + days)%7
        weekday = weekday_mapping_[weekday_number]
        weekday = ', '+weekday

    days = ' (' + str(days) + ' days later)' if days>1 else ' (next day)' if days == 1 else ''

    print(str(hrhours) + ':' + str(f'{minsminutes:02d}') + ' ' + ampm + weekday + days)
    new_time = str(hrhours) + ':' + str(f'{minsminutes:02d}') + ' ' + ampm + weekday + days
    return new_time