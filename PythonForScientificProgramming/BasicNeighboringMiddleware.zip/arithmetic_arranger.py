import numpy as np
def arithmetic_arranger(problems, result=False):
    len_of_input = len(problems)
    print(len_of_input)
    if len_of_input >5:
        return "Error: Too many problems."

    # Operator must be '+' or '-'.
    operators = [True if i.split(' ')[1] in ['+','-'] else False for i in problems]
    if False in operators:
        return "Error: Operator must be '+' or '-'."

    # Numbers cannot be more than four digits.
    operand_1 = [i.split(' ')[0] for i in problems]
    operand_2 = [i.split(' ')[2] for i in problems]
    if False in [True if len(i) <= 4 else False for i in operand_1] or False in [True if len(i) <= 4 else False for i in operand_2]:
        return "Error: Numbers cannot be more than four digits."

    # Error: Numbers must only contain digits.
    if False in [True if i.isdigit() else False for i in operand_1] or False in [True if i.isdigit() else False for i in operand_2]:
        return "Error: Numbers must only contain digits."


    # max value length
    max_length = [max(len(i.split(' ')[0]),len(i.split(' ')[2])) for i in problems]

    if result:
        arranged_problems = ''
        for i in np.array([[f"{i.split(' ')[0]:>{max_length[_] + 2}}",
                            i.split(' ')[1] + ' ' + f"{i.split(' ')[2]:>{max_length[_]}}", '-' * (max_length[_] + 2),
                            f"{eval(i.split(' ')[0] + i.split(' ')[1] + i.split(' ')[2]):>{max_length[_] + 2}}"] for
                           _, i in
                           enumerate(problems)]).T.tolist():
            arranged_problems = arranged_problems + '    '.join(i) + '\n'
    else:
        arranged_problems = ''
        for i in np.array([[f"{i.split(' ')[0]:>{max_length[_] + 2}}",
                            i.split(' ')[1] + ' ' + f"{i.split(' ')[2]:>{max_length[_]}}", '-' * (max_length[_] + 2)]
                           for _, i in
                           enumerate(problems)]).T.tolist():
            arranged_problems = arranged_problems + '    '.join(i) + '\n'

    return arranged_problems[:-1]